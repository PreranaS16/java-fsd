package project4;

//parameterized constructor

 class demo {
	int id;
	String name;

	demo(int i,String n)
	{
	id=i;
	name=n;
	}

	void display() {
	System.out.println(id+" "+name);
	}
}

public class Constructor2 {
public static void main(String[] args) {

	demo std1=new demo(2,"Alex");
	demo std2=new demo(10,"Annie");
	std1.display();
	std2.display();
		}


}

package project1;

public class Typecasting {

	public static void main(String[] args) {
		// Explicit type 
		
		float a=22.7f;
		int b=(int)a;
		//converting bigger data type to smaller data type.
		System.out.println("output of b is " +b);
		
		
		
		//Implicit type
		
		int c=1;
		float d=c;
		//converting smaller data type into bigger data type.
		System.out.println("output of d is "+d);

	}

}

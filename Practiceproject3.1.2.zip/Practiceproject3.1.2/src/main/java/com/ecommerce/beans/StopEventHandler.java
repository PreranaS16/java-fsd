package com.ecommerce.beans;

public class StopEventHandler {

}

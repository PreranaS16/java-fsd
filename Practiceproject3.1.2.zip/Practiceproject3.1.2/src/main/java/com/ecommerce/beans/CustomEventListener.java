package com.ecommerce.beans;

public class CustomEventListener {

}

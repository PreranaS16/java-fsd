package project5;

import java.util.*;

public class LinkedHash {
       public static void main(String[] args) {
		
		LinkedHashSet <Integer> lh = new LinkedHashSet <Integer> ();
		
		lh.add(90);
		lh.add(70);
		lh.add(10);
		lh.add(30);
		lh.add(50);
		
		System.err.println(lh);

	}

}

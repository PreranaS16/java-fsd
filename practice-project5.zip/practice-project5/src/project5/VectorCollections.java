package project5;

import java.util.*;

public class VectorCollections {
       public static void main(String[] args) {
		
		Vector <String> v = new Vector <String> ();
		
		v.addElement("Sam");
		v.addElement("Dil");
		v.addElement("Raj");
		v.addElement("Rev");
		v.addElement("Adi");
		
		System.out.println(v);

	}

}

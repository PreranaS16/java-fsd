package project5;

import java.util.*;

public class Linked {
       public static void main(String[] args) {
		
		LinkedList <String> l = new LinkedList <String> ();
		
		l.add("DevOps");
		l.add("Dev");
		l.add("Test");
		l.add("Dev");
		l.add("Sap");
		
		Iterator <String> it = l.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		//System.out.println(l);
		
	
	}

}

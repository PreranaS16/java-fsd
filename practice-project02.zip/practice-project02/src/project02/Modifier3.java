package project02;

public class Modifier3 {
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}


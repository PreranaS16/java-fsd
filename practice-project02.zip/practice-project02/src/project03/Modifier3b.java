package project03;

import project02.*;
public class Modifier3b extends Modifier3 {
	public static void main(String[] args) {
		Modifier3b obj = new Modifier3b ();   
	       obj.display();  
	}


}

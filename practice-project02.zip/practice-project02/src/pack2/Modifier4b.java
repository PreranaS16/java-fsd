package pack2;

import pack1.*;
public class Modifier4b {
public static void main(String[] args) {
		
		Modifier4 obj = new Modifier4(); 
        obj.display();  
		
	}

	

}

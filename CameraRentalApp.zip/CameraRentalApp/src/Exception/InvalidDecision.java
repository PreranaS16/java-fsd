package Exception;

public class InvalidDecision extends Exception {

	@Override
	public String toString() {
		return "Invalid decision Choose only deposit or not";
	}
	

}

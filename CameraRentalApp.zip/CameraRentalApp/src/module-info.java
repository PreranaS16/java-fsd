/**
 * 
 */
/**
 * @author prajwal gowda
 *
 */
module CameraRentalApp {
}